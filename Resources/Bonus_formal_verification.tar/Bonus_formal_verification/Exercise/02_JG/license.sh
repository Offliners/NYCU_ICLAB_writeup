setenv LM_LICENSE_FILE 5280@cad1.ee.nctu.edu.tw:${LM_LICENSE_FILE}
